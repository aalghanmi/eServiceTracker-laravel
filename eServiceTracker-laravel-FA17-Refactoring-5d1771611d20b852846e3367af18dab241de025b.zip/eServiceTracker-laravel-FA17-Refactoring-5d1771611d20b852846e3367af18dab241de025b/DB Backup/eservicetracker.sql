-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 08, 2017 at 10:53 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `eservicetracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `act_id` int(9) NOT NULL,
  `std_id` int(3) NOT NULL,
  `spc_act_id` int(9) NOT NULL,
  `act_tab` varchar(11) NOT NULL,
  `act_time` varchar(10) NOT NULL,
  `act_date` varchar(10) NOT NULL,
  `act_name` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`act_id`, `std_id`, `spc_act_id`, `act_tab`, `act_time`, `act_date`, `act_name`) VALUES
(69, 43, 1, 'services', '10:08 pm', '2017-04-27', 'insertForm'),
(68, 43, 127, 'services', '01:17 am', '2017-01-19', 'insertForm'),
(67, 43, 0, 'services', '01:10 am', '2017-01-19', 'insertForm'),
(66, 43, 127, 'services', '09:47 pm', '2016-09-24', 'insertForm'),
(40, 43, 106, 'services', '03:38:am', '09-22-16', 'insertForm'),
(41, 43, 107, 'services', '12:20:pm', '09-22-16', 'insertForm'),
(42, 43, 108, 'services', '12:21:pm', '09-22-16', 'insertForm'),
(43, 43, 109, 'services', '12:21:pm', '09-22-16', 'insertForm'),
(44, 43, 110, 'services', '12:21:pm', '09-22-16', 'insertForm'),
(45, 43, 111, 'services', '12:22:pm', '09-22-16', 'insertForm'),
(46, 43, 112, 'services', '12:22:pm', '09-22-16', 'insertForm'),
(47, 43, 113, 'services', '12:22:pm', '09-22-16', 'insertForm'),
(48, 43, 114, 'services', '12:27:pm', '09-22-16', 'insertForm'),
(49, 43, 115, 'services', '12:35:pm', '09-22-16', 'insertForm'),
(50, 43, 116, 'services', '07:23:pm', '09-22-16', 'insertForm'),
(51, 43, 117, 'services', '07:27:pm', '09-22-16', 'insertForm'),
(52, 43, 118, 'services', '07:28:pm', '09-22-16', 'insertForm'),
(53, 43, 119, 'services', '07:32:pm', '09-22-16', 'insertForm'),
(54, 43, 120, 'services', '07:33:pm', '09-22-16', 'insertForm'),
(55, 43, 121, 'services', '07:34:pm', '09-22-16', 'insertForm'),
(64, 43, 125, 'services', '04:40 pm', '2016-09-24', 'insertForm'),
(65, 43, 126, 'services', '04:41 pm', '2016-09-24', 'insertForm');

-- --------------------------------------------------------

--
-- Table structure for table `advisors`
--

CREATE TABLE `advisors` (
  `adv_id` int(10) UNSIGNED NOT NULL,
  `adv_fname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adv_lname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adv_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adv_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `remember_token` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `advisors`
--

INSERT INTO `advisors` (`adv_id`, `adv_fname`, `adv_lname`, `adv_email`, `adv_password`, `is_admin`, `is_active`, `remember_token`, `created_at`, `updated_at`) VALUES
(9, 'Wangel', 'Tamang', 'lamadipen@gmail.com', '$2y$10$wX0FLUomjNnOQ.vFSlhXF.dSr3jFo/7xyW0JbnwrEjEcbi5QZvvCO', 0, 1, '', '2016-03-15 01:54:48', '2016-03-15 01:54:48'),
(12, 'Wangdel ', 'Lama', 'wangel@prep-villa.com', '$2y$10$Tb65CBmcYNTXz8MEFDXp9Oialc..Cwib9brOFs/CfbuJfy3LutoVC', 2, 1, '0s0AW9j2aszHR0sQT5c1lu7c1G0SjtzdLatO3Vg1w43PrccXxwJILaL7BoNB', '2016-09-28 02:14:29', '2017-10-26 23:11:02'),
(13, 'Anas', 'Alghanmi', 'anas@prep-villa.com', '$2y$10$Tb65CBmcYNTXz8MEFDXp9Oialc..Cwib9brOFs/CfbuJfy3LutoVC', 2, 1, 'c2ynHV9Nkl5F0kJynqvqDFqeydtkn7vV6YGRsmlUPMOg5IGJVJq49GowUUXL', '2016-09-28 02:14:29', '2017-09-26 03:18:10');

-- --------------------------------------------------------

--
-- Table structure for table `esc_group`
--

CREATE TABLE `esc_group` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `code` varchar(64) NOT NULL,
  `advisors` int(3) NOT NULL,
  `students` int(5) NOT NULL,
  `subscription_time` int(1) NOT NULL,
  `subscription_type` tinyint(1) NOT NULL,
  `admin_name` text NOT NULL,
  `admin_email` varchar(64) NOT NULL,
  `admin_phone` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `esc_group`
--

INSERT INTO `esc_group` (`id`, `name`, `code`, `advisors`, `students`, `subscription_time`, `subscription_type`, `admin_name`, `admin_email`, `admin_phone`) VALUES
(1, 'Florida University', 'GAN-110-111', 25, 99, 6, 0, '', '', 0),
(7, 'Epic Web Studios', 'epi-7509-9457', 5, 25, 3, 1, '', '', 0),
(8, 'Villa Maria Academy', 'Vil-9458-3786', 5, 25, 99, 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2016_02_04_164028_create_advisors_table', 1),
('2016_02_04_164148_create_settings_table', 1),
('2016_02_04_164218_create_service_types_table', 1),
('2016_02_04_164249_create_organizations_table', 1),
('2016_02_04_164314_create_supervisors_table', 1),
('2016_02_04_164327_create_service_statuses_table', 1),
('2016_02_04_164340_create_services_table', 1),
('2016_02_04_164410_create_volunteer_hours_table', 1),
('2016_02_04_164500_create_students_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notification_users`
--

CREATE TABLE `notification_users` (
  `nu_id` int(9) NOT NULL,
  `nu_token` int(40) NOT NULL,
  `std_id` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE `organizations` (
  `org_id` int(10) UNSIGNED NOT NULL,
  `ser_id` int(10) NOT NULL,
  `org_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `org_desc` varchar(800) COLLATE utf8_unicode_ci NOT NULL,
  `org_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`org_id`, `ser_id`, `org_name`, `org_desc`, `org_address`, `created_at`, `updated_at`) VALUES
(99, 106, 'Baba ji ki Jai o!', 'I was describing the love toward\'s baba ji', '119th parade Street towards the center of the Green House', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(100, 107, 'bhulbhulaiya', 'test desc', '211 west 8th street', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(101, 108, 'test1', 'test desc', '211 west 8th street', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(102, 109, 'Biggy Ezze', 'test desc', '211 west 8th street', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(103, 110, 'test1', 'test desc', '211 west 8th street', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(104, 111, '2 Pac Rap Arena', 'test desc', '211 west 8th street', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(105, 112, 'test1', 'test desc', '211 west 8th street', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(106, 113, 'test1', 'test desc', '211 west 8th street', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(107, 114, 'test2', 'Hello Desc', '211 Norwigan St', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(108, 115, 'test 3 :)', 'Hello this is test 3 hehe !', 'Near Kothala', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(109, 116, 'Suman Rai', 'Hello Nothing', '211 West 8th Street', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(110, 117, 'testing service', 'hello nting', 'Near zoomlas house', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(111, 118, 'Testing three', 'This is a proper description of what it should be', '12312 asdaslkdmalkdm', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(112, 119, 'eight', 'eidsadkald', '1312smalskmd', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(113, 120, 'Hello', 'Nothing', '211 Eest 9th Form', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(114, 121, 'next smash is 100', 'adnlanmdlanl', '21321 dsadas', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(115, 122, 'Skililimi', 'i did nothing basiclaly', '211 est 8th street', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(116, 123, 'this is a last test that i am doing in the fucking world of shit and beshiting', 'this is a last test that i am doing in the fucking', 'Near my house', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(117, 124, 'ab cde fg', 'hello i did nothing', 'some random place', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(118, 125, 'Wangel tamang', 'h no', '2312 asdasda dada', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(119, 126, 'Asian–African Legal Consultative Organization', 'It is a long established fact that ', '1311 Versailles Ave', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(120, 0, 'testing org', 'i did something that was easy', '211 west 8th steet', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(121, 127, 'Test Organization 1', 'Description of the organization', '211 west 8th steet', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(122, 1, 'abcde', 'adasdas', '817 walnut street', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `school_emails`
--

CREATE TABLE `school_emails` (
  `id` int(11) NOT NULL,
  `suffix` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_emails`
--

INSERT INTO `school_emails` (`id`, `suffix`, `created_at`, `updated_at`) VALUES
(10, 'prep-villa.com', '2016-06-20 18:17:12', '2016-05-05 09:39:49'),
(2, '@grandschool.com', '2016-04-27 17:12:46', '2016-04-27 17:12:46'),
(3, '@grandschool.com', '2016-04-27 17:14:42', '2016-04-27 17:14:42'),
(4, '@grandschool.com', '2016-04-27 17:15:27', '2016-04-27 17:15:27'),
(11, '@prep-villa.com', '2016-07-13 22:01:16', '2016-05-26 11:16:32'),
(6, '@vma.com', '2016-05-02 10:00:07', '2016-05-02 10:00:07'),
(7, '@prep-villa.com', '2016-05-04 07:07:18', '2016-05-04 07:07:18'),
(8, 'prep-villa', '2016-05-04 07:22:23', '2016-05-04 07:22:23'),
(9, 'gmail', '2016-05-04 08:09:21', '2016-05-04 08:09:21'),
(12, 'prep-villa.com', '2016-07-24 06:34:43', '2016-07-24 06:34:43'),
(13, 'prep-villa.com', '2016-08-11 15:25:08', '2016-08-11 15:25:08'),
(14, 'prep-villa', '2016-08-11 15:25:56', '2016-08-11 15:25:56');

-- --------------------------------------------------------

--
-- Table structure for table `school_years`
--

CREATE TABLE `school_years` (
  `id` int(11) NOT NULL,
  `sch_year` date NOT NULL,
  `is_current` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_years`
--

INSERT INTO `school_years` (`id`, `sch_year`, `is_current`, `created_at`, `updated_at`) VALUES
(11, '2015-01-01', 1, '2017-10-31 03:42:46', '2017-10-31 03:42:46'),
(12, '2017-10-01', 1, '2017-10-31 03:43:04', '2017-10-31 03:43:04'),
(14, '2018-08-01', 1, '2017-11-02 00:26:01', '2017-11-02 00:26:01');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `ser_id` int(10) UNSIGNED NOT NULL,
  `ser_date` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ser_hr` int(3) NOT NULL,
  `ser_min` int(2) NOT NULL DEFAULT '0',
  `std_id` int(11) NOT NULL,
  `serty_id` int(10) NOT NULL,
  `sers_id` int(10) NOT NULL,
  `school_year` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `adv_id` int(10) NOT NULL,
  `flag` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`ser_id`, `ser_date`, `ser_hr`, `ser_min`, `std_id`, `serty_id`, `sers_id`, `school_year`, `created_at`, `updated_at`, `adv_id`, `flag`) VALUES
(106, '2017-11-14', 12, 15, 43, 3, 1, '2017-10-01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 13, 0),
(107, '2016-06-11', 17, 15, 43, 2, 1, '2015-01-01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 13, 0),
(120, '2015-05-14', 20, 15, 43, 3, 1, '2016-01-01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 13, 0),
(121, '2015-11-14', 12, 15, 43, 3, 1, '2015-01-01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 13, 0),
(126, '2017-11-18', 33, 15, 43, 2, 1, '2017-10-01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 13, 0);

-- --------------------------------------------------------

--
-- Table structure for table `service_statuses`
--

CREATE TABLE `service_statuses` (
  `sers_id` int(10) UNSIGNED NOT NULL,
  `sers_stat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `service_statuses`
--

INSERT INTO `service_statuses` (`sers_id`, `sers_stat`, `created_at`, `updated_at`) VALUES
(1, 'Accepted', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Rejected', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Pending', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `service_types`
--

CREATE TABLE `service_types` (
  `serty_id` int(10) UNSIGNED NOT NULL,
  `serty_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `service_types`
--

INSERT INTO `service_types` (`serty_id`, `serty_name`, `created_at`, `updated_at`) VALUES
(1, 'Home Alone', '2016-02-17 10:13:40', '2016-02-17 10:13:40'),
(2, 'Poverty', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'abcde', '2017-05-23 08:36:52', '2017-05-23 08:36:52'),
(5, 'TEST', '2017-10-26 20:51:12', '2017-10-26 20:51:12');

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE `session` (
  `sn_id` int(9) NOT NULL,
  `sn_user_id` int(9) NOT NULL,
  `sn_status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `sett_id` int(10) UNSIGNED NOT NULL,
  `service_types` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `hours` int(11) NOT NULL,
  `school_year` date NOT NULL,
  `email` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`sett_id`, `service_types`, `hours`, `school_year`, `email`, `created_at`, `updated_at`) VALUES
(1, 'Home Alone\r,Poverty\r,Something else\r', 12, '2017-08-01', 'prep-villa.com', '2016-02-17 10:39:20', '2017-10-26 21:58:52');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `std_id` int(10) UNSIGNED NOT NULL,
  `std_fname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `std_lname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `std_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `std_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `std_gradYear` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `std_isActive` tinyint(1) NOT NULL,
  `std_isPassedOut` tinyint(1) NOT NULL,
  `std_agreement` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`std_id`, `std_fname`, `std_lname`, `std_email`, `std_password`, `std_gradYear`, `std_isActive`, `std_isPassedOut`, `std_agreement`, `created_at`, `updated_at`) VALUES
(34, 'Dipen', 'Lama', 'lama001@knights.gannon.edu', 'pokemon', '2016', 0, 0, 1, '0000-00-00 00:00:00', '2016-12-14 08:41:42'),
(42, 'Nozomi', 'Yukimura', 'nozomi@prep-villa.com', '906e372a34a68454e0963573aa948595', '2016', 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(43, 'Wangel', 'Lama', 'wangel@prep-villa.com', '906e372a34a68454e0963573aa948595', '2020', 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(44, 'Joe', 'Bell', 'a@b.c', '12345', '2019', 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `supervisors`
--

CREATE TABLE `supervisors` (
  `sup_id` int(10) UNSIGNED NOT NULL,
  `sup_fname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sup_lname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sup_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sup_phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ser_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `supervisors`
--

INSERT INTO `supervisors` (`sup_id`, `sup_fname`, `sup_lname`, `sup_email`, `sup_phone`, `created_at`, `updated_at`, `ser_id`) VALUES
(2, 'wanglkjk', '', 'hinko@gmail.com', '8887878889', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 107),
(3, 'wanglkjk', '', 'hinko@gmail.com', '8887878889', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 108),
(4, 'wanglkjk', '', 'hinko@gmail.com', '8887878889', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 109),
(5, 'wanglkjk', '', 'hinko@gmail.com', '8887878889', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 110),
(6, 'wanglkjk', '', 'hinko@gmail.com', '8887878889', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 111),
(7, 'wanglkjk', '', 'hinko@gmail.com', '8887878889', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 112),
(8, 'wanglkjk', '', 'hinko@gmail.com', '8887878889', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 113),
(9, 'neema lama', '', 'neema@hotmail.com', '4543562345', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 114),
(10, 'Seema Lama', '', 'seema@hotmail.com', '8148069574', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 115),
(11, 'Wangel Tamang', '', 'wangel@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 116),
(12, 'neelam lama', '', 'wangel@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 117),
(13, 'Nikesh Lama', '', 'wangel@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 118),
(14, 'Neeram', '', 'neerma@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 119),
(15, 'Nikita karki', '', 'supervisor@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 120),
(16, 'Neelama', '', 'neelalm@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 121),
(17, 'sdadasda', '', 'dasdas@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122),
(18, 'Neeran Limbu', '', 'neera@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 123),
(19, 'Neemla beemla', '', 'neemla@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 124),
(20, 'Nicholas Cage', '', 'nicholas@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 125),
(21, 'Suman Lama', '', 'tester@gmail.com', '9898987656', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 126),
(22, 'wangel', '', 'wangel@prep-villa.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(23, 'Suman karki', '', 'suman@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 127),
(24, 'dasdsa', '', 'wangel@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(9) NOT NULL,
  `group_id` int(9) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `email` varchar(64) NOT NULL,
  `phone` varchar(24) NOT NULL,
  `password` varchar(64) NOT NULL,
  `level` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `flag` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `group_id`, `firstname`, `lastname`, `email`, `phone`, `password`, `level`, `status`, `flag`) VALUES
(1, 7, 'John', 'Doe', 'aaaa@gmail.com', '9989989898', '', 3, 1, 1),
(4, 7, 'Anita', 'Subba', 'subba.anita17@yahoo.com', '', '$2y$10$mOQbXlHJ.8XiIK5FQn/EI.Ce/k32bzPDfl.H/4uY9h3Fix8dtKukK', 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_hours`
--

CREATE TABLE `volunteer_hours` (
  `vh_id` int(10) UNSIGNED NOT NULL,
  `vh_done` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `ser_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`act_id`);

--
-- Indexes for table `advisors`
--
ALTER TABLE `advisors`
  ADD PRIMARY KEY (`adv_id`);

--
-- Indexes for table `esc_group`
--
ALTER TABLE `esc_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_users`
--
ALTER TABLE `notification_users`
  ADD PRIMARY KEY (`nu_id`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`org_id`);

--
-- Indexes for table `school_emails`
--
ALTER TABLE `school_emails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_years`
--
ALTER TABLE `school_years`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`ser_id`);

--
-- Indexes for table `service_statuses`
--
ALTER TABLE `service_statuses`
  ADD PRIMARY KEY (`sers_id`);

--
-- Indexes for table `service_types`
--
ALTER TABLE `service_types`
  ADD PRIMARY KEY (`serty_id`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`sn_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`sett_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`std_id`);

--
-- Indexes for table `supervisors`
--
ALTER TABLE `supervisors`
  ADD PRIMARY KEY (`sup_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `volunteer_hours`
--
ALTER TABLE `volunteer_hours`
  ADD PRIMARY KEY (`vh_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `act_id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `advisors`
--
ALTER TABLE `advisors`
  MODIFY `adv_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `esc_group`
--
ALTER TABLE `esc_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `notification_users`
--
ALTER TABLE `notification_users`
  MODIFY `nu_id` int(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `organizations`
--
ALTER TABLE `organizations`
  MODIFY `org_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;
--
-- AUTO_INCREMENT for table `school_emails`
--
ALTER TABLE `school_emails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `school_years`
--
ALTER TABLE `school_years`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `ser_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;
--
-- AUTO_INCREMENT for table `service_statuses`
--
ALTER TABLE `service_statuses`
  MODIFY `sers_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `service_types`
--
ALTER TABLE `service_types`
  MODIFY `serty_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `session`
--
ALTER TABLE `session`
  MODIFY `sn_id` int(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `sett_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `std_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `supervisors`
--
ALTER TABLE `supervisors`
  MODIFY `sup_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `volunteer_hours`
--
ALTER TABLE `volunteer_hours`
  MODIFY `vh_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;