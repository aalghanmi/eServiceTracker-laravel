<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    protected $table = "users";
    public $timestamps = false;

    //protected $fillable = ['lastname', 'firstname','email','phone','group_id','status'];
    protected $hidden = ['password', 'remember_token'];

    public function getAdministrator($id){
        return $data = Admin::findOrNew($id);
    }


}
