<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model {

	//
    protected $table = 'students';

    protected $primaryKey = 'std_id';

    protected $fillable = ['std_isActive','std_fname','std_lname','std_email'];

    public function get_vol_hours()
    {
         return $this->hasMany('App\VolunteerHour', 'std_id');
    }

    /**
     * Get the service names for the student.
    */
    public function get_services()
    {
         return $this->hasMany('App\Service', 'std_id');
    }


    /**
     * Get volunteer hours and service names for the student.
     */
    public function get_service_hours()
    {
        return $this->hasManyThrough('App\ServiceStatus','App\Service' ,'std_id','sers_id');
    }




}
