<?php namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ServiceType extends Model {

	//
     protected $primaryKey = 'serty_id';


    /* Returns All Service Types (serty_id, serty_name)*/
    public function get_all_service_types(){

        /* Fetch Service Types */
        $serty_data = DB::table('service_types')
            ->select('serty_id','serty_name')->get();

        return convertToArray($serty_data);
    }
    /*
    private function convertToArray($data){

        $data = array_map(function($object){
            return (array) $object;
        }, $data);
        return $data;

    }
    */
}
