<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model {

     protected $primaryKey = 'sett_id';
     
     public function serviceType()
     {
        return $this->belongsToMany('App\ServiceType','serty_id');
     }

    public function get_service_types(){

        //return $allServiceTypes = $this->belongsTo('App\ServiceType','get_all_service_types');
        return convertToArray($allServiceTypes);
    }

    /*
    private function convertToArray($data){

        $data = array_map(function($object){
            return (array) $object;
        }, $data);
        return $data;

    }
    */
    
    public function get_settings_school_year(){
        $sy = \DB::table('settings')->select('school_year')->get();
        return convertToArray($sy);
    }

    public function get_settings(){
        $sy = \DB::table('settings')->select('school_year')->get();
        return $this->convertToArray($sy);
    }

    public function get_all_settings($id){
        $all = \DB::table('settings')->where('sett_id','=',$id)->get();
        return convertToArray($all);
    }

}
