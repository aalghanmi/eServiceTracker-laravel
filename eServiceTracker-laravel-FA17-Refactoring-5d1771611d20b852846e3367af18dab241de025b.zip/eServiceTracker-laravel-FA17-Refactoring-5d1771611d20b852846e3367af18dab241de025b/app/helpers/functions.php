<?php
function convertToArray($data){
    $data = array_map(function($object){
        return (array) $object;
    }, $data);
    return $data;
}

function fetchstudentServiceData($ser_id = null)
{
        $std_data = \DB::table('students')
           ->join('services', 'services.std_id', '=', 'students.std_id')
           ->join('advisors', 'services.adv_id', '=', 'advisors.adv_id')
           ->join('supervisors', 'services.ser_id', '=', 'supervisors.ser_id')
           ->join('service_types', 'services.serty_id', '=', 'service_types.serty_id')
           ->join('organizations', 'services.ser_id','=','organizations.ser_id')
           ->select('students.std_fname',
               'students.std_id',
               'students.std_lname',
               'students.std_email',
               'services.ser_id',
               'services.ser_hr',
               'services.ser_date',
               'services.sers_id',
               'advisors.adv_id',
               'advisors.adv_fname',
               'advisors.adv_lname',
               'supervisors.sup_id',
               'supervisors.sup_fname',
               'supervisors.sup_email',
               'service_types.serty_id',
               'service_types.serty_name',
               'organizations.org_id',
               'organizations.org_name',
               'organizations.org_desc')
           ->where('services.ser_id',$ser_id)
           ->get();

        return $std_data;
}