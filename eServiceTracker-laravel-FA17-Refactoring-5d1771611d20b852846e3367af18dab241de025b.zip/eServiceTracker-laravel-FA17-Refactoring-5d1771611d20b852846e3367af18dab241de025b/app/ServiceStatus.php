<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceStatus extends Model {

	//
    protected $primaryKey = 'sers_id';

}
