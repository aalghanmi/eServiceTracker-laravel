<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/




    Route::group(['middleware' => ['web']], function () {
    Route::get('/', function () {
        //return View::make('dashboard');
        return View::make('dashboard.list');
    });
    Route::get('/login', function() { return View::make('advisor.adv_login'); });
    Route::post('auth/login', 'Auth\CustomAuthController@postLogin');
    Route::get('/logout', function(){ Auth::logout() ; return View::make('advisor.adv_login');});
    
    Route::get('advisor/register', 'AdvisorController@create');
    Route::post('advisor/register', 'AdvisorController@store'); 
    

});



/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web','auth']], function () {
    
    // All my routes that needs a logged in user  
    Route::get('advisor/notification', function(){
	return view("advisor.advisor_notification");
    });
    Route::get('advisor/student_detail/{id}', 'AdvisorController@getStudentDetail');
    Route::get('advisor/manage_volunteer_hour', 'AdvisorController@filter_student_list');
    Route::get('advisor/update_service_status/{id}/{status}', 'AdvisorController@updateServiceStatus');
    Route::get('advisor/update_student_status/{id}/{status}', 'AdvisorController@updateStudentStatus');
    Route::get('advisor/edit_volunteer_hour/{id}', 'AdvisorController@editVolunteerHour');
    Route::get('invite', function() { return View::make('advisor.advisor_invite'); });
    Route::get('studentinvite', function() { return View::make('advisor.student_invite'); });
    Route::get('service_detail/{id}','AdvisorController@dispaly_aggregate_edit_form' );


    Route::get('settings/');
   
    
    Route::post('advisor/send_invitation','AdvisorController@sendEmailInvitation');
    Route::post('advisor/send_invitation_student','AdvisorController@sendEmailStudentInvitation');
    Route::post('advisor/update_volunteer_hour','AdvisorController@updateStudentHour');
    Route::post('advisor/manage_volunteer_hour', 'AdvisorController@filter_student_list');
    Route::post('advisor/search_student', 'AdvisorController@searchStdByName');
    Route::post('advisor/notify', 'AdvisorController@send_notification');
    Route::post('advisor/filter', 'AdvisorController@filter_student_list');
    Route::post('update_service_detail', 'AdvisorController@update_aggregate_edit_form'); 
    Route::post('delete_student/{id}','AdvisorController@destroy_student' );
    Route::post('notify_student/{id}','AdvisorController@sendEmailStudentNotification' );


    Route::post('advisor/update_volunteer_service/','AdvisorController@update_volunteer_service');

    Route::resource('dashboard','DashController');
    Route::resource('advisor','AdvisorController');
    Route::resource('servicetype','ServiceTypeController');
    Route::resource('settings','SettingController');
    Route::resource('schoolYear','SchoolYearController');
    Route::resource('student','StudentController');
    Route::resource('school_email','SchoolEmailController');
    Route::resource('group','GroupController');
    Route::resource('admin','AdminController');
     
});