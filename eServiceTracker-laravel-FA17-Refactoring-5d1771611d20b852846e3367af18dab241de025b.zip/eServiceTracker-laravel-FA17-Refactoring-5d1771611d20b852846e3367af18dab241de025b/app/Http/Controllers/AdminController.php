<?php

namespace App\Http\Controllers;

use App\Admin;
use App\Group;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $admin = Admin::all();
        $group = Group::all();
        return view('admin.list')->with('admins', $admin)->with('groups', $group);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $group = Group::all();
        return view('admin.create')->with('groups', $group);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $admin = new Admin();
        $admin->firstname = $request->firstname;
        $admin->lastname = $request->lastname;
        $admin->email = $request->email;
        $admin->phone = $request->phone;
        $admin->level = 3;
        $admin->status = $request->status;
        $admin->password = bcrypt($request->password);
        $admin->flag = 1;
        $admin->group_id = $request->group;
        $admin->save();

        return redirect('admin');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       
          return redirect()->route('admin.edit', $id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $admin = new Admin();
        $data = $admin->getAdministrator($id);
        $group = Group::all();
        return view('admin.edit')->with('groups', $group)->with('admin',$data);

    }

    /**
     * Update the specified resource in storage
     */
    public function update( Request $request, $id)
    {

        try{
            
            $admin = Admin::findOrFail($id);
         if( !empty(  $request->firstname ) ){
            $admin->firstname = $request->firstname;
         }
        if( !empty($request->lastname ) ){
            $admin->lastname = $request->lastname;
        }
         if( !empty( $request->email ) ){
            $admin->email = $request->email;
        }
         if( !empty( $request->phone ) ){
            $admin->phone = $request->phone;
        }
         if( !empty(  $request->group) ){
            $admin->group_id = $request->group;
        }
         if( !empty( $request->status) ){
            $admin->status = $request->status;
        }
            if( !empty( $request->password ) ){
                $admin->password = bcrypt($request->password);
            }
            $admin->save();
        }catch(\Exception $e){
            echo $e->getMessage();
        }

        return redirect()->route('admin.edit', $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $admin = Admin::find($id);
        $admin->delete();

        $admin = Admin::all();
        $group = Group::all();
        return view('admin.list')->with('admins', $admin)->with('groups', $group);
    }
}
