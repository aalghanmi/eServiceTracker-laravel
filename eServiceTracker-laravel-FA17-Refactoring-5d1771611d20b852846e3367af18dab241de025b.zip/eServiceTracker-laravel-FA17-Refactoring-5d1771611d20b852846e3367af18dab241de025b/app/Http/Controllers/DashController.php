<?php

namespace App\Http\Controllers;

use App\Service;
use App\ServiceType;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use PhpParser\Node\Expr\Cast\Array_;

class DashController extends Controller
{

    public function index()
    {

        $totalHrsByYear = $this->total_hours_by_grad_year();
        $totalHrsBySchool = $this->total_hours_by_entire_school();

        $total_service_hours = $totalHrsBySchool[0]['total_service_hours'];
        $total_year_hours = $totalHrsByYear[0]['total_service_hours'];
        $total_service_type_hours = $this->total_hours_accepted_by_service_type();

        $studentsMostAcceptedHrs = $this->students_with_most_hours_accepted();
        $studentsMostAcceptedHrsYear = $this->students_with_most_hours_by_grad_year();

        if( Auth::user()->level != 2 ):
            return view('dashboard.list')
                ->with('total_service_hours',$total_service_hours)
                ->with('total_year_hours', $total_year_hours)
                ->with('total_service_type_hours',$total_service_type_hours)
                ->with('students_with_most_hours_accpted',$studentsMostAcceptedHrs)
                ->with('students_with_most_hours_by_grad_year',$studentsMostAcceptedHrsYear);
        else:
            return view('dashboard.alternateList');
        endif;
    }

    


    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        return view('dash.show');
    }


    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }

    public function view_dashboard(){

    }

    private function total_hours_by_grad_year(){

        $startDate = date("Y")."-01-01";
        $endDate = date("Y")."-12-31";
        $total_query = \DB::table('services')
                        ->select(DB::raw('DISTINCT std_id,sum(ser_hr) as total_service_hours'))
                        ->where('sers_id','=','1')
                        ->whereBetween('ser_date',[$startDate,$endDate])
                        ->get();

        return convertToArray($total_query);

    }

    /* Returns total hour and std_id */
    private function total_hours_by_entire_school(){

        $total_query = \DB::table('services')
            ->select(DB::raw('sum(ser_hr) as total_service_hours'))
            ->where('sers_id','=','1')
            ->get();
        return convertToArray($total_query);
    }

    /* Returns Service Type ID with the total service hours accepted */
    public function total_hours_accepted_by_service_type(){

        $service_types = new ServiceType();
        $list = $service_types->get_all_service_types();

        $services = convertToArray($list);

        $result_list = [];
        foreach($services as $service) {

            $query = \DB::table('services')
                        ->select(DB::raw('DISTINCT std_id,serty_id,sum(ser_hr) as total_service_hours'))
                        ->where('serty_id', '=', $service["serty_id"])->get();
            $results = convertToArray( $query );

            foreach($results as $result){
                $serty_id = ( $result['serty_id'] == null ) ? 0 : $result['serty_id'];
                $total_service_hours = ( $result['total_service_hours'] == null ) ? 0 : $result['total_service_hours'];
                array_push( $result_list,array($serty_id,$total_service_hours,$service['serty_name']) );
            }
        }

        return $result_list;

    }

    public function query_joiner($maxhours){
        $query = \DB::table('services')
                    ->join('students', 'services.std_id', '=', 'students.std_id')
                    ->select(DB::raw('students.std_fname,students.std_lname,services.std_id,SUM(services.ser_hr) as total_service_hours'))
                    ->groupBy('services.std_id')
                    ->orderBy('total_service_hours','desc')
                    ->limit(5)
                    ->get();
        if($maxhours="All"){
            return convertToArray( $query ) ;
        }
        if($maxhours="Grad"){
            $sdate = date("Y")."-01-01";
            $edate = date("Y")."-12-31";
            $query = $query
            ->whereBetween('services.ser_date',[$sdate,$edate]);
            return convertToArray( $query ) ;
        }

    }

    public function students_with_most_hours_accepted(){
        $mosthours="All";
        return $this->query_joiner($mosthours);

    }

    public function students_with_most_hours_by_grad_year(){
        $mosthours="Grad";
         return $this->query_joiner($mosthours);

        $sdate = date("Y")."-01-01";
        $edate = date("Y")."-12-31";

        $query = \DB::table('services')
            ->join('students', 'services.std_id', '=', 'students.std_id')
            ->select(DB::raw('students.std_fname,students.std_lname,services.std_id,SUM(services.ser_hr) as total_service_hours'))
            ->groupBy('services.std_id')
            ->orderBy('total_service_hours','desc')
            ->whereBetween('services.ser_date',[$sdate,$edate])
            ->limit(5)
            ->get();

        return convertToArray( $query ) ;

    }

    /*
    private function convertToArray($data){

        $data = array_map(function($object){
            return (array) $object;
        }, $data);
        return $data;

    }
    */

}
