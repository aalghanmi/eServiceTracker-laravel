<?php

namespace App\Http\Controllers;

use App\Group;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

//use App\Http\Requests;
//use App\Http\Controllers\Controller;

class GroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $group = Group::all();
        return view('group.show')->with('group',$group);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('group.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $group = new Group;
        $pin = $group->generatePIN();
        $pin2 = $group->generatePIN();
        $this->getGroupData($group);
        $group->code = ucwords(substr(Input::get('name'),0,3)).'-'.$pin.'-'.$pin2;
        $group->save();
        return Redirect::to('group');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $group = Group::findOrNew($id);
        return view('group.edit')->with('data',$group);
    }

    /**
     * Update the specified resource in storagexx.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $group = Group::findOrNew($id);
        $this->getGroupData($group);
        $group->save();
        return redirect('group/'.$id.'/edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $group = Group::findOrNew($id);
        $group->delete();
        return Redirect::to('group');
    }

    /**
     * @param $group
     */
    public function getGroupData($group)
    {
        $group->name = Input::get('name');
        $group->advisors = Input::get('advisors');
        $group->students = Input::get('students');
        $group->subscription_type = Input::get('subscription_type');
        $group->subscription_time = Input::get('subscription_time');
    }
}
