<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Setting;
use App\ServiceType;


class SettingController extends Controller {

	 // Display a listing of the resource.
	public function index()
	{
        return view('settings.create');
	}
    
	 //Show the form for creating a new resource.
	

	 // Store a newly created resource in storage.
	public function store(Request $request)
	{
        $setting = new Setting();
        $setting->sett_hour = $request->hour;
        
        $setting->save();
        return Redirect::to('setting');
	}

	//Display the specified resource.
	public function show($id)
	{
        echo $id;
	}

	 //Show the form for editing the specified resource.
	public function edit($id)
	{
        $settings = new Setting();
        $serviceType = new ServiceType();

        $all_settings = $settings->get_all_settings($id);
        $service_types = $serviceType->get_all_service_types();

        return view('advisor.settings.edit') ->with('service_types',$service_types) ->with('all_settings',$all_settings[0]);
	}

	 //Update the specified resource in storage.
	public function update($id)
	{
        $setting = Setting::find($id);
        $setting->school_year = Input::get('new_sch_year');
        $setting->hours = Input::get('hours');
        $setting->email = Input::get('email');
        $setting->save();

        return redirect('settings/'.$id.'/edit');
	}


	 // Remove the specified resource from storage.
	public function destroy($id)
	{
		//
        $setting = Setting::find($id);
        $setting->delete();
        
        return redirect()->route('setting.index');
	}



}